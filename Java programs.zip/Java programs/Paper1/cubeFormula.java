class cubeFormula
{
    public static void main(String[] args){

        System.out.println("program Started");

        double side = 5.5;

        double total_surface_area = 6*side*side;
        double lateral_surface_area = 4*side*side;
        double volume_of_cube = side*side*side;
        double perimeter_of_cube = 12*side;
        
        System.out.println("Total surface of area is" +  + total_surface_area);
        System.out.println("lateral surface area is" +  + lateral_surface_area);
        System.out.println("volume of cube is " +  + volume_of_cube);
        System.out.println("perimeter of cube is "+  +perimeter_of_cube);
        
        System.out.println("program ended");

    }
}