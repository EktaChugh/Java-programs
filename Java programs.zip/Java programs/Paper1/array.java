public class array{
    public static int sum_array(int[] a){
        int t=0;
        for(int i=0; i<a.length; i++){
         t+=a[i];
        }

        return t;
    }
    public static int average_array(int[] a){
        int t=0;
        for(int i=0; i<a.length; i++){
            t+=a[i];
        }

        return t;
    }
    public static void main(String[] args){
        int[] arr={10, 20, 30, 40, 50};
        System.out.println("Summ of array is " + sum_array(arr));
        System.out.println("Average of array is " + average_array(arr));
    }
}