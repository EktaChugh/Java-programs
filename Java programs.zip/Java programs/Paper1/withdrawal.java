class withdrawal
{
    public static boolean check_suff(int bal, int withdraw){
        if(bal>withdraw){
            return true;
        }
        else {
            return false;
        }
    }
    public static void main(String[] args){
     
        int bal = 10000;
        int with_draw = 2000;
       
         System.out.print(check_suff(bal,with_draw));
    }
}