import java.util.*;
public class formula {
    public static int square(int val){
        return val*val;
    }
    public static void main(String[] args){
        Scanner ob = new Scanner(System.in);
        System.out.println("type a value of a");
        int a=ob.nextInt();
        System.out.println("type a value of b");
        int b=ob.nextInt();
        int c = square(a) + square(b) +(2*a*b);
        System.out.println(c);
    }
}