class evennumber
{
    public static void main(String[] args)
    {
    int[]evenNumber={1,3,2,5,8,10,11,15,16,18,20};
        for(int i=0; i<evenNumber.length; i++)
    {
            if(evenNumber[i]%2==0)
            {
                System.out.println(evenNumber[i]);
            }

        }
    }

}