class reverseOrder
{
    public static void main(String[] args)

    {
    int[]reverseOrder={10,20,30,40,50};
       

        for(int i=reverseOrder.length-1; i>=0; i--)

        {
            System.out.println(reverseOrder[i]);

        }
    }

}
