class squareOfElement
{
    public static void main(String[] args){
    int[]squareOfElement={10,11,12};

    for(int i=0;i<squareOfElement.length;i++)
    {
        
        System.out.println(squareOfElement[i]*squareOfElement[i]);
        
        
    }
}
}