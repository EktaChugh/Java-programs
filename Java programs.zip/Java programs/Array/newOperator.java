class newOperator
{
    public static void main(String[] args){

        int[] newOperator=new int[5];
        newOperator={0,5,7,8,9};
        System.out.println(newOperator[0]);
    }
}