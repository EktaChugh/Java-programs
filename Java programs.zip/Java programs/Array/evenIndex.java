class evenIndex
{
    public static void main(String[] args){
        
    int[]evenIndex={1,5,5,48,7,93,40};

    for(int i=0;i<evenIndex.length;i++)
    {
       if(i%2==0){
        System.out.println(evenIndex[i]);
       
        }

    }
     
    }
}