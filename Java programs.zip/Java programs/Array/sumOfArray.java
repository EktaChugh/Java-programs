class sumOfArray
{
    public static void main(String[] args)
    {
    int[]sumOfArray={10,50,60,42};
    
    int sum =0;
    
    for (int i=0;i<sumOfArray.length;i++)
    {
     sum=sum+sumOfArray[i];
     
    }
    System.out.println("sum of element of array:" +sum);
        
    
    }
}