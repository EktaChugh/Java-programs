import java.util.Scanner;
class reverseorder {
    public static void main(String[] args){

        int[] arr = new int[5];
        Scanner input=new Scanner(System.in);
        int index=0;
        for (int i=0;i<5;i++)
        {
            System.out.println("input value of "+i);
            arr[i]=input.nextInt();
        }
        System.out.println("values is in reverse order");

        while(index>=0)
        {
            System.out.print(" "+arr[index--]+" ");
        }
    }
}