class program2
{
    public static void main(String[] args){
        System.out.println("Program Started");
        // array creation
        int[] arr1 = new int[5];

      //store values in array
      arr1[0]=12;
      arr1[1]=24;
      arr1[2]=36;
      arr1[3]=48;
      arr1[4]=50;

      //arrayname.length----->gives the size of array
System.out.println("Array size is"+arr1.length);
System.out.println("print all the element of array");

int index = 0;
while(index<arr1.length)
{
    System.out.println(arr1[index++]);   
}


//for(int i=0;i<5;i++)
{
    //System.out.println(arr1[i]);
    }
}
}