class program4
{
    public static void main(String[] args){
        System.out.println("Program started");
        String[] subjects=new String[5];//String array is created
        // this array can hold 5 string values
        
        //storing values
        subjects[0]="java";
        subjects[1]="SQL";
        subjects[2]="apti";
        subjects[3]="logical programming";
        subjects[4]="web";

        System.out.println("print all subjects");

        int index=0;
        while(index < subjects.length){
            System.out.println(subjects[index++]);


        System.out.println("replace a subject present in index 2 by new subject");
        subjects[2]="Framework";
        System.out.println("print all subjects");

    index=0;
    while(index<subjects.length){
        System.out.println(subjects[index++]);
    {
    System.out.println("program ended");

}
    }

