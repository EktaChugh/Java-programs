class Assignmentformula
{ 
    public static void main(String[] args)
    {
        double mass = 200;
        double volume = 150;
        double Density = mass/volume;

        System.out.println("Density: "+Density); 
    }
}