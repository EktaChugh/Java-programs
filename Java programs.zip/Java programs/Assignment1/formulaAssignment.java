class formulaAssignment
{ 
    public static void main(String[] args)
    {
        double mass = 200, volume = 150, work = 20, time = 2, acceleration = 100, gravity = 9.8, current = 2, resistance = 50, velocity = 50, radius = 50, Pi = 3.14, side = 50, length = 400, breathe = 200, height = 800;
        int a = 10, b = 20;


        double density = mass/volume;
        double power = work/time;
        double newton_second_law = mass*acceleration;
        double weight = mass*gravity;
        double ohm_law = current*resistance;
        double kinetic_energy = (0.5)*mass*velocity;
        double area_of_spear = 4*3.14*radius*radius;
        double cube_volume = side*side*side;
        double area_of_trapezoid = (length+breathe)*height;
        int result = a*a + b*b + 2*a*b;
        
        

        System.out.println("Density: "+density); 
        System.out.println("\nPower: "+power); 
        System.out.println("\nForce (Newton second law): "+newton_second_law); 
        System.out.println("\nWeight: "+weight); 
        System.out.println("\nOhm_law: "+ohm_law);
        System.out.println("\nKinetic Energy: "+kinetic_energy); 
        System.out.println("\nArea of Spear: "+area_of_spear); 
        System.out.println("\nCube Volume: "+cube_volume);  
        System.out.println("\nArea of Trapezoid: "+area_of_trapezoid);
        System.out.println("\nResult: "+result);


    }
}