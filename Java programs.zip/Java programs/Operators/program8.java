class program8
{
    public static void main(String[] agrs){        
        //int x=0;
        //int y=0;
        int t;
  
        y=++x + x;

        //System.out.println(x);
        //System.out.println(y);
        System.out.println(t);
}
}