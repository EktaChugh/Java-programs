class program11
{
    public static void main
}