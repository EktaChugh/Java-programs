class Program1
{
    public static void main(String[] args)
    {
        double radius=2.1;
        final double pi=3.14;
        double diameter, area , circumference;

        //calculations
        diameter = 2*radius;
        area = pi*radius*radius;
        circumference = 2*pi*radius;

        System.out.println("radius of circle: "+radius);
        System.out.println("diameter of circle: "+diameter);
        System.out.println("area of circle: "+area);
        System.out.println("circumference of circle: "+circumference);

    }
}
