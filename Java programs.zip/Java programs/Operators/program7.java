class program7
{
    public static void main(String[] agrs){        
        int x=0;
        int y=0;
  
        y=++x;

        System.out.println(x);
        System.out.println(y);
}
}