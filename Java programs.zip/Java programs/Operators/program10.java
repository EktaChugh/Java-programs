class program10
{
    public static void main(String[] agrs){        
        int x=0;
        int y=0;
  
        y=++x + x++ + ++x + x++ + ++x + x++ + ++x + x++ + ++x;

        System.out.println(x);
        System.out.println(y);
}
}