class program4
{
    public static void main(String[] args) {
        double accbal=100000;
        double withamt=5000;
        double depamt=8000;

        System.out.println("Amount Balance is"+accbal);
        System.out.println("Withamt is"+withamt);
        accbal-= withamt;
        System.out.println("Amount Balance is Rs "+accbal);
        System.out.println("Deposting Rs"+depamt);
        accbal+= depamt;
        System.out.println("Amount Balance is Rs"+accbal);


    }
}