class Program3
{
    public static void main(String[] args)
    {
        double Base = 10;
        double height = 30;
        double area = (0.5) * Base * height;        
        
        System.out.println("Area of triangle: "+area);
    }
}