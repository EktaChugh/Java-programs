class program5
{
    public static void main(String[] agrs){
        int x=10;
        int y=15;
        int z=50;

        System.out.println(x>y && y>z);
        System.out.println(x<y && z<x);
        System.out.println(x>y||z>x || y>z);
        System.out.println(!(x>y ));
        System.out.println(!(!(x>y)));
    }
}