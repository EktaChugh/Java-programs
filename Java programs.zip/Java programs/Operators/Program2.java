class Program2
{
    public static void main(String[] args)
    {
        double Principal = 10;
        double Rate_of_Interest = 30;
        double time = 5;

        //calculations
        double Simple_Intrest = Principal * Rate_of_Interest *time ;
        
        System.out.println("Simple Intrest is: "+Simple_Intrest);
    }
}