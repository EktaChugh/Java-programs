class program1
{
    public static void main(String[] agrs)
    {
    System.out.println("number is"+20);
    System.out.println(20+"is the number");
 
    System.out.println("number is"+20+20);
    System.out.println("number is"+(20+20));
    System.out.println(20+20+"is the number");
    System.out.println('a'+'b');
     } 
}