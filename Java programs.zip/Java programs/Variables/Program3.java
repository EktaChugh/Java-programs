class Program3
{
    public static void main(String[] args)
    {
        //variable declaration
    int number=29;
    double result=number/3;
    
     //variable initialization

      System.out.println(result);
    }
}

