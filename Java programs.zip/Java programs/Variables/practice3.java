class practice3
{
    public static void main(String[] args)
    {

        //System.out.println("Ekta's");
        System.out.println("\"This is Ekta's house\"");
        System.out.println(1/2);
    }
}