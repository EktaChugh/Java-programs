import java.util.Scanner; 
class practice1
{

    public static void main(String[]args)
     {
    Scanner idnumber = new Scanner(System.in);
    Scanner salary = new Scanner(System.in);

    System.out.print("Enter an idnumber: ");
    int num = idnumber.nextInt();
    System.out.print("Enter the salary: ");


    
    int num1 = salary.nextInt();

    System.out.println("You entered: " + num);
    System.out.println("You entered: " + num1);
}
}