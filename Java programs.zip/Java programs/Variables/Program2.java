class Program2
{
    public static void main(String[] args)
    {
        float marks=58.32f;
        long pno=9851562123l;

        System.out.println(marks);
        System.out.println(pno);
    }

}