class Program1
{
    public static void main(String[] args)
    {
    //variable declaration
    int empage;
    double empsalary;
    char empgrade;
    String empName;

    //variable initialization
    empage=24;
    empsalary=35000.00;
    empgrade='A';
    empName="Guneet";   

    System.out.println(empage);
    System.out.println(empsalary);
    System.out.println(empgrade);
    System.out.println(empage+empsalary+empgrade);
    System.out.println(empage+"\t"+empsalary+"\t"+empgrade);
    System.out.println(empage+" "+empsalary+" "+empgrade);
    System.out.println(empage+"\n"+empsalary+"\n"+empgrade);
    System.out.println(empage+","+empsalary+",uhhu"+empgrade);
    System.out.println(empName);
    
    }
}