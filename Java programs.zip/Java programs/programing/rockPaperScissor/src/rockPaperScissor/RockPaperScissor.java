package rockPaperScissor;

public class RockPaperScissor {
 
}
