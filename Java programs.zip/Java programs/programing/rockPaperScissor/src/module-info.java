/**
 * 
 */
/**
 * 
 */
module rockPaperScissor {
}