/**
 * 
 */
/**
 * 
 */
module rockPaper {
}