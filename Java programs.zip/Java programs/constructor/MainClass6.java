class GraphPoint2D
{
double xaxis;
double yaxis;

GraphPoint2D(double xaxis,double yaxis)
{
    this.xaxis=xaxis;
    this.yaxis=yaxis;
}
void updateXaxis(double xaxis){
    this.xaxis=xaxis;

}
void updateYaxis(double yaxis){
    this.yaxis=yaxis;
}
void displayCoOrdinates(){
    System.out.println("("+xaxis+","+yaxis+")");
}
}
class MainClass6
{
    public static void main(String[] agrs){
        System.out.println("Main method started");
        GraphPoint2D p1 = new GraphPoint2D(1.2,5.6);
        p1.displayCoOrdinates();
        GraphPoint2D p2 = new GraphPoint2D(4.9,8.6);
        p2.displayCoOrdinates();
        System.out.println("update xaxis of p1");
       p1.updateXaxis(6.2);
       p1.displayCoOrdinates();

    System.out.println("main method ended");
    }
}