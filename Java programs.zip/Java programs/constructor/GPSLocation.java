class GPSLocation1
{
double longitute;
double latitude;
char diraction;

GPSLocation1(double longitute,double latitude,char diraction)
{
    this.longitute=longitute;
    this.latitude=latitude;
    this.diraction=diraction;
}
void updatelongitute(double longitute){
    this.longitute=longitute;

}
void updatelatitude(double latitude){
    this.latitude=latitude;
}
void updatediraction(char diraction){
    this.diraction=diraction;
}
void displayCoOrdinates(){
    System.out.println("("+longitute+","+latitude+","+diraction+")");
}
}
class GPSLocation
{
    public static void main(String[] agrs){
        System.out.println("Main method started");
        GPSLocation1 p1 = new GPSLocation1(1.2,5.6,'n');
        p1.displayCoOrdinates();
        GPSLocation1 p2 = new GPSLocation1(4.9,8.6,'n');
        p2.displayCoOrdinates();
        System.out.println("update longitute of p1");
       p1.updatelongitute(6.2);
       p1.displayCoOrdinates();

    System.out.println("main method ended");
    }
}