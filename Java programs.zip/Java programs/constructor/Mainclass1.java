class Employees{
    static int startid = 10001;
    final int id;
    String name;
    double exp;
    double salary;
    String designation;
    Employees(String name, double exp, double salary, String designation){
        this.id = startid++;
        this.name=name;
        this.exp = exp;
        this.salary = salary;
        this.designation =designation;
    }
    void emp_details(){
        System.out.print("ID:"+id+"Name:"+name);
    }
    }
    public class Mainclass1{
        public static void main(String[] args){
            Employees e1 = new Employees("ekta",5.2,500000,"Software engineer");
            e1.emp_details();
            Employees e2 = new Employees("ekta",5.2,500000,"Software engineer");
            e2.emp_details();
            Employees e3 = new Employees("ekta",5.2,500000,"Software engineer");
            e3.emp_details();

        }
    }


    