class Employees{
    final int y;// one copy per object and its constant
    Employees(int z){
        y=z;
    }
}
public static Mainclass2{
    public static void main(String[] args){
        Employees d1 = new employees(52);// passing emp id
    System.out.println("y value is" +d1.y);
    Employees d2 = new employees(53);// passing employee id
    System.out.println("y value is" +d2.y);
    }
}