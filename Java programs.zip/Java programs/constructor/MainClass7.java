class Circle
{
    double radius;
    final static double pi=3.14;

    Circle(double radius){
        this.radius=radius;
    }
    void displayradius(){
        System.out.println("Radius: "+radius);
    }
    void updateRadius(double radius){
        this.radius=radius;
    }
    void diameter(){
        double dia = 2* radius;
        System.out
        Public static void main(String[] agrs){

        }
    }
}