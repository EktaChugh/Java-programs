class program2
{
    public static void main(String[] args){
        System.out.println("Program Started");
        int n=10;
        if (n%2==0){
    
            System.out.println(n+"is even Number");
        }
        else
        {
            System.out.println(n+"is odd Number");   
        }
        
        System.out.println("Program Ended");
    }
}