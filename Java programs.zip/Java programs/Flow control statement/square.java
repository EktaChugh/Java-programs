class square
{
    public static void main(String[] args){

        for (int i=1; i<=20; i++)
        {
            int res=0;
            res =i*i;
            System.out.println("square of"+i"is" +res);
        }
        
    }
}