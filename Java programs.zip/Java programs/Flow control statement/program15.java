class program15
{
    public static void main(String[] args){
        System.out.println("Program started");
        int n=1;
        while(n<=10)
{
    System.out.println(n+" ");
    n++;

}
System.out.println("Program Ended");
    }
}