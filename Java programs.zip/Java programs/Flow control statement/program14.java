class program14
{
    public static void main(String[] args)
    {
        System.out.println("Program Started");
        for (int i=1;i<=10;i++)
        {
            if(i==5||i==7)
            continue;
        System.out.println("Program Started");
        
        }
        }
    }
