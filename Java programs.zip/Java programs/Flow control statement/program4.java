class program4
{
    public static void main(String[] args){

        System.out.println("Program Started");
        int n=9;
        if (n%3==0)
        {
            System.out.println("FIZZ");
        }
    
        else if (n%5==0)
        {
            System.out.println("BUZZ");   
        }
        else if(n%3==0 && n%5==0)
        {
            System.out.println("FIZZBUZZ");    
        }
         System.out.println("Program Ended");
    }
}