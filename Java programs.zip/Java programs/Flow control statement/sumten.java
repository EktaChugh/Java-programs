class tensum
{
    public static void main(String[] args){
        int i=1 ,sum=0;
        {
            while(i<=10){
            System.out.println("summation:"+sum);
            i++;
        }
    }
    }
}