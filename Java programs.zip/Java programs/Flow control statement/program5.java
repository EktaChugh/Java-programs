class program5
{
    public static void main(String[] args){
        System.out.println("program started");
        double accbal=5000.00;
        double amount=8000.00;

        if(amount<accbal)
        {
            accbal=accbal-amount;
            System.out.println("withdraw success");
        }
        else
        {
            System.out.println("withdraw failed due to insufficient account balance");
            System.out.println("please try later....");

        }
        System.out.println("account balance:"+accbal);
        System.out.println("program ended");
        
    
    }
}