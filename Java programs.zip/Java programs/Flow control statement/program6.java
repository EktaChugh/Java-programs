class program6
{
    public static void main(String[] args){
        System.out.println("program started");
        double accbal=5000.00;
        double amount=8000.00;
        int exp_pin=1234;
        int input_pin=1233;
        if(input_pin==exp_pin)//outer if
        {
            System.out.println("Valid PIN");
            if(amount < accbal)//inner if
        {

            accbal=accbal-amount;
            System.out.println("withdraw success");
        }
        else
        {
            System.out.println("withdraw failed due to insufficient account balance");
            System.out.println("please try later....");
        }

        System.out.println("account balance:"+accbal);
    }
    else
    {
        System.out.println("Invalid PIN:cannot do transaction");
    }

        System.out.println("program ended");
}
    
    }
