class program11
{
    public static void main(String[] argsr){
    System.out.println("Program Started");
    for (int i=1;i<=10;i++)
    {
        int res=0;
        res=i*i;
        System.out.println("Square of "+i"is"+ res);

    }
    System.out.println("Program ended");

}
}