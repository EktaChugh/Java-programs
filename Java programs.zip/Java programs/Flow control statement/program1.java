class program1
{
    public static void main(String[] args){
        System.out.println("Program Started");
        int n=5;
        if(n>7)
        {
            System.out.println("Number is above 7");
        }
        else if (n==7)
        {
            System.out.println("Number is equal to 7");
            
        }
        else
        {
            System.out.println("Number is below 7");  
        }
        System.out.println("Program Ended");
    }
}