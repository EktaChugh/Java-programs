class program7
{
    public static void main(String[] args){
        System.out.println("program started");

        char grade='A';
        switch (grade)
        {
        
            case 'A':System.out.println("First class with distinction");
                     break;
            case 'B':System.out.println("First class");
                     break;
            case 'C':System.out.println("Second class");
                     break;
            case 'D':System.out.println("Just pass");
                     break;
            case 'E':System.out.println("Get LOss");
                     break;
            default:System.out.println("Invaild Grade");
                     break;
        }
        System.out.println("program ended");
    
    }
}