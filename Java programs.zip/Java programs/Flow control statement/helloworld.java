class helloworld
{
    public static void main(String[] args){
    System.out.println("Program Started");
    int n=1;
    while(n<=6){
    System.out.println("Hello world");
    n++;
    }
    
    System.out.println("Program Ended");
    }
}


