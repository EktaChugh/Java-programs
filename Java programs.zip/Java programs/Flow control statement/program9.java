class program9
{
    public static void main(String[] args){
    System.out.println("Program started");
    for(int i=1;i<=10;i++)
    {
        System.out.print(i+" ");
    }
    {
        System.out.println("\n......\n");
    }
    for(int j=10;j>=1;j--)
    {
        System.out.print(j+" ");   
    }
    {
        System.out.println("\n Program Ended");
    }
}
}