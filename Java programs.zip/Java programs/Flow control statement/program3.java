class program3
{
    public static void main(String[] args){

        System.out.println("Program Started");
        int x=100;
        int y=20;
        int z=500;

        if (x>y && x>z)
        {
    
            System.out.println("x is bigger");
        }
        else if (y>x && y>z)
        {
            System.out.println("y is bigger");   
        }
        else
        {
            System.out.println("z is bigger");    
        }
        
        System.out.println("Program Ended");
    }
}