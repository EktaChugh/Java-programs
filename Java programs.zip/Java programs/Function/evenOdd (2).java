class checkEven
{
    public static boolean evenOdd (int num)
    {
        System.out.println("running test() method");
        
        if(num%2==0)
            return true;
        
        else
            return false;

           // return num%2==0;
    }
        
        
        public static void main(String [] args){
        
           System.out.println(evenOdd(10));
           
        }
    }
