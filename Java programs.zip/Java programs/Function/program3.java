class program3
{
    public static void main(String[] args){
        System.out.println("main method started");
        square(5);
        System.out.println(square(6));
        int x = square(7);
        System.out.println("x value is" +x);
        System.out.println("main method ended");
    }
    public static int square(int num)
    {
        int res=num*num;
        return res;

    }
}