class program5
{
    public static int[] demofunc(){
        int[] arr1={12,13,15,18,68};
        return arr1;
}
public static void main (String[] args){
    System.out.println("main method started");

    int[] retArr= demofunc();
    for(int i=0; i<retArr.length;i++)
    System.out.println(retArr[i]);
}

}