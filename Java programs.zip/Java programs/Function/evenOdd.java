class evenOdd
{
    public static boolean evenOdd ()
    {
        System.out.println("running test() method");
        int x = 6;
        if(x%2==0){
            return true;
        }
        else{
            return false;
        }
        }
        public static void main(String [] args)

 
        {
            int x=10;
           System.out.println(x);
           //System.out.println(y);
        }
    }
