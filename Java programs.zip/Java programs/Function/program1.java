class program1
{
    public static int test ()
    {
        System.out.println("running test() method");
        int x = 6;
        if(x>7){
            return x;
        }
        else{
            return 0;
        }
        }
        public static void main(String [] args)

 
        {
           System.out.println(test());
           int x= test();
           System.out.println(x);
        }
    }
