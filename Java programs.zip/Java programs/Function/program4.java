class program4
{
    public static void main(String[] args)
    {
        System.out.println("main method started");
        test();
        System.out.println(test());

       // int x=test();
        System.out.println("main method ended");
    
    }   
        public static String test(){
    System.out.println("running test() method");
    return " ";
    }

}
