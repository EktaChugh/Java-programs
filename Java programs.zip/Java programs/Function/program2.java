class program2
{
    public static void main(String [] args){
        System.out.println(" main method started");
        double rad = 2.1;
        final double pi =3.14;
        System.out.println("radius is:" +rad);
        System.out.println("diameter :" + diameter(rad));
        System.out.println("area:" + area(rad,pi));
        System.out.println("circumference :"+ circumference(rad,pi));
        System.out.println("main method ended");
    }

        public static double diameter(double radius)
        {
            return 2*radius;
        }
        public static double circumference(double radius, double pie)
        {
            
            return pie * radius * radius;
        }
        public static double area(double radius, double pie){
        return 2* pie * radius;

    
}
}