class Demo5
{
int p = 100;
int q = 200;
}
class Mainclass6
public static void main(String[] args){
    System.out.println("main method started");
    Demo5 d1 =  new Demo5();
    Demo5 d2 =  new Demo5();
    Demo5 d3 =  new Demo5();
    System.out.println(d1);
    System.out.println(d2);
    System.out.println(d3);
}