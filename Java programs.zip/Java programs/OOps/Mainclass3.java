class Demo3
{
    int x = 100;
    int y = 300;
    void test()
    {
        System.out.println("running non static test()");
            }
}
class Mainclass3
{
public static void main(String[] args){
    System.out.println("main method started");
    System.out.println("x valus is"+ new Demo3().x);
    System.out.println("y value is "+ new Demo3().y);
    new Demo3().test();
    System.out.print("main method ended");
}
}