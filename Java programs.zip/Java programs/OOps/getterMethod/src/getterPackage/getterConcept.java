package getterPackage;

public class getterConcept {
private int id;
private String name;
private double salary;

getterConcept(int id,String name,double salary){
this.id=id;
this.name=name;
this.salary=salary;
}
public int get id()
{
	return this.id;
}
public String get name()
{
	return this.name;
}
public double get salary()
{
	return this.salary;
}
public void setId(int id) {
	this.id=id;
}
public void setName(String name) {
	this.id=id;
}
