class Demo5
{
    int x =10;
    double y = 4.5;
}
class Mainclass5
{
    public static void main(String[] agrs){
        System.out.println("main method started");
        Demo5 d1 = new Demo5();
        Demo5 d2 = new Demo5();
        System.out.println("using d1");
        System.out.println("x is"+d1.x+"y is"+d1.y);
        System.out.println("using d2");
        System.out.println("x is"+d2.x+"y is"+d2.y);
        System.out.println("modify x and y using d1");
        d1.x = 45;
        d1.y= 25.5;
        System.out.println("using d1 printing x and y");
        System.out.println("x is"+d1.x+"y is"+d1.y);
        System.out.println("using d2 printing x and y");
        System.out.println("x is"+d2.x+"y is"+d2.y);
    }
}
