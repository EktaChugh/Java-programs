class phonenumber{
    String brand;
    double price;
    String colour;
    void write{
        System.out.println("writing is using"+colour +"colourpen");
    }
    class Mainclass9
    {
        Public static void main(String[] agrs){
            pen p1
            p1= new pen p1();
            p1 brand = "addgel";
            p1 colour = "Black";
            p1 price= "10.00";
            System.out.println("Brand:"+brand+"Colour:"+colour+"price:"+price);
            p1 write();

        }
    }
}