import java.util.Scanner;
class Program16
{
    public static void main(String[] agrs){
        System.out.println("main method started");
        Scanner scn1 = new Scanner(System.in);
        System.out.println("enter username");
        String Username = scn1.next();
        System.out.println("enter userage");
        int Userage = scn1.nextInt();
        System.out.println("enter usermarks");
        Double usermarks = scn1.nextDouble();
        System.out.println("enter user phonenumber");
        long userphnnum = scn1.nextLong();
        System.out.println(Username+" "+Userage+" "+usermarks+" "+userphnnum);
    }
    }
