package doWhile;

import java.util.Scanner;

public class countNumber {
	public static void main(String[] args) {
		Scanner ip= new Scanner(System.in);
		int n = ip.nextInt();
		int c=0;
		while(n!=0) {
			n=n/10;
			c++;
		}
		System.out.println("count:"+c);
		
	}

}