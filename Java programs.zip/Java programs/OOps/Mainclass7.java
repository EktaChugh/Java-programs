class Demo7
{
    int p = 100;
    int q = 200;
}
class Mainclass7
{
    public static void main(String[] agrs)
    {
        demo T d1;
        d1 = new class T;
        System.out.println(d1.p);
        System.out.println(d1.q);
        d1.p = 300;
        d1.q= 400;
        d1 = new class T;
        System.out.println(d1.p);
        System.out.println(d1.p);

    }
}