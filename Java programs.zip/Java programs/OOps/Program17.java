class Program17
{
    public static void test()
    {
        System.out.print(" running test() method");
    }
    public static void main(String[] agrs){
        System.out.println("main method started");
        test();
        System.out.println("main method ended");

    }
}