class print 
{
    void test()
    {
        System.out.println("running test()");

    }
}
class print1
{
    public static void main(String[] args){
        System.out.println("running main() of print1 class");

    }
}
class print2
{
    public static void main(String[] args){
        System.out.println("running main() of print2 class");
    }
}