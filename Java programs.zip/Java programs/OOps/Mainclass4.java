class Demo4
{
    int x = 10;
    int y = 20;
    void test()
    {
        System.out.println("running nonstatic method test()");
    }
}
class Mainclass4
{
    public static void main(String [] args){
        System.out.println(" main method start");

        Demo4 d1;
        d1 =  new Demo4();
        System.out.println("x value is "+ d1.x);
        System.out.println("y value is "+ d1.y);
        d1.test();
        System.out.println("modify xand y ");
        d1.x =25;
        d1.y=30;
        System.out.println("x value is"+d1.x);
        System.out.println("y value is"+d1.y);
        System.out.println("main method ended");
    }
}
