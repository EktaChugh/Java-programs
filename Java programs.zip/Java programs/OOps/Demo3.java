class Demo3
double y;
int x;
Demo3()
{
    this.x=10;
    this.y=15.2;
}
Demo3(int x);
this.x=x;
}
Demo3(double y){
    this.y=y;
}
Demo3(int x , double y){
    this.x = x;
    this.y=y;
}
void display(){
    System.out.println("x=")
}