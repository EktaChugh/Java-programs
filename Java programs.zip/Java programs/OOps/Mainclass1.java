class Demo2
{
    static int p = 10;
    static int q = 20;
}
class Mainclass1
{
    public static void main(String[] args){
        System.out.println("main method started");
        System.out.println("p value is+ Demo2.p");
        System.out.println("q value is+ Demo2.q");
        System.out.println("re-initialise static variable p and q");
        Demo2.p = 30;
        Demo2.q = 40;
        System.out.println("p valus is "+ Demo2.p);
        System.out.println("q value is "+ Demo2.q);
        System.out.print("main method ended");

    }
}