class Program1
{
    static int x =10;
    static int y = 20;
    static void test()
    {
        System.out.print("Running Static test()");
    }
}
class Mainclass
{
    public static void main(String[] args){
        System.out.println("main method started");
        System.out.println("x value is "+ Program1.x);
        System.out.println("y value is "+Program1.y);
        Program1.test();
        System.out.print("main method ended");
    }
}

