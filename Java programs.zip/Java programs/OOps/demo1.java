public final class demo1
{
    static  int x =10;
    int y=20;

    static void test(){
        System.out.println("running test()");
        int a =100;
    }
    void disp(){
        System.out.println("running disp() method");
        int b=200;
        
    }
}