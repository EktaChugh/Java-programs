public final class demo2
{
    static int x = 10;
    static int y = 20;
    static void test()
    System.out.println("running test()....");
    int a = 100;
}
void disp(){
    System.out.println("running desp() method");
    int b = 200;
}

