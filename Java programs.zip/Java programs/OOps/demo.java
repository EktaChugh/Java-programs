class demo
{
    int x = 100;
    int y=200;
    void test()
    {
        System.out.println("running non static test()");
    }
}

    class MainClass
    {
        public static void main(String[] args) {
            System.out.println("main method started");
            System.out.println("x value is"+ new demo().x);
            System.out.println("y value is"+ new demo().y);
            new demo().test();
            System.out.println("main method ended");
        }
    }