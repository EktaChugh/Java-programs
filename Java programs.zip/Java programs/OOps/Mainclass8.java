class Demo8
{
    int x = 100;
    int y = 200;
}
class Mainclass8
{
    public static void main(String[] agrs){
        Demo8 d1,d2;
        d1= new Demo8();
        d2=d1;
        System.out.println(d1);
        System.out.println(d2);
        d1.x = 300;
        d2.y = 400;
        System.out.println(d2.x);
        System.out.println(d2.y);
    }
}
