public class Bike
{
    void Bike()
    {
        System.out.println("Method");
    }
    Bike()
    {
        System.out.println("constructor");
    }
public static void main(String[] args){
    Bike b1 = new Bike();
    b1.Bike();
}
}