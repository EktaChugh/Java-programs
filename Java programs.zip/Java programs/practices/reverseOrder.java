class reverseOrder
{
    public static int[] reverseArray(int[] arr){
        int[] revArr = new int[arr.length];
        for(int i=arr.length-1,j=0;j<revArr.length;i--,j++)
{
    revArr[j]=arr[i];
}
    return revArr;
}
    public static void main(String[] args){
    int[]givenArr={10,20,30,40,50};
    int[] retarr = reverseArray(givenArr);
    for(int i=0;i<retarr.length;i++)
        {
            System.out.println(retarr[i]);
        }

    }

}