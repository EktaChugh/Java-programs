class Demo94
{
    int p = 100;
    int q = 200;
}
    class MainClass94{
        public static void main(String[] args){
            System.out.println("main method started");
            Demo94 d1 = new Demo94();
            Demo94 d2 = new Demo94();
            Demo94 d3 = new Demo94();
            System.out.println("d1");
            System.out.println("d2");
            System.out.println("d3");
        }
}
