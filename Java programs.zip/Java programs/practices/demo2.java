class demo2{
    public static void test()
    {
        System.out.println("running test() method");
    }
    public static void main(String[] agrs){
        System.out.println("main method started");
        test();
        System.out.println("main method ended");
    }
}