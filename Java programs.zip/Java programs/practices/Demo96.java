class Demo96
{
    int x = 100;
    int y = 200;
    void test(){
        System.out.println("running non static test()....");
    }
}
class MainClass4
{
    public static void main(String[] args){
    System.out.println("main method started");
    Demo96 d1;
    d1 = new Demo96();
    System.out.println("x value is"+ d1.x);
    System.out.println("y value is"+ d1.y);
    d1.test();
    System.out.println("modify x and y value");
    d1.x=25;
    d1.x=30;
    System.out.println("x value is"+ d1.x);
    System.out.println("y value is"+ d1.y);
    }
}
