class program2
{
    public static void main(String[] args){
        System.out.println("program started");
        int n=50;
        if(n%3==0)
        {
            System.out.println("FIZZ");
        }
        else if(n%5==0)
        {
            System.out.println("BUZZ");
        }
        else if(n%3==0 && n%5==0)
        {
            System.out.println("FIZZBUZZ");
        }
        System.out.println("program ended");
}
}