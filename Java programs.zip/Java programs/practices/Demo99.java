public class Demo99
{
    static int x = 110;
    static int y = 500;
    static void test(){
    System.out.println("running static test()....");
    }
}
class MainClass1
{
        public static void main(String[] agrs){
        System.out.println("main method started");
        System.out.println("x value is"+Demo99.x);
        System.out.println("y value is"+Demo99.y);
        Demo99.test();
        System.out.println("main method ended");
}
}