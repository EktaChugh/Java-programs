import java.util.Scanner;
class demo1{
     public static void main(String[] args){
        System.out.println("main method started");
        Scanner Scn1 = new Scanner(System.in);
        System.out.println("enter username");
        String username=Scn1.next();

        System.out.println("enter userage");
        int userage = Scn1.nextInt();

        System.out.println("enter gender");
        char gender= Scn1.next().charAt(0);

        System.out.println("enter usermarks");
        double usermarks = Scn1.nextDouble();

        System.out.println("enter userphoneno");
        long userphoneno = Scn1.nextLong();

        System.out.println(username+" "+userage+" "+gender+" "+usermarks+" "+userphoneno);
     }
    }






        

     