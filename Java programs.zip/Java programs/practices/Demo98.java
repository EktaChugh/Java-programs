class Demo98
{
static int p = 10;
static int q = 20;
}
class MainClass2
{
    public static void main(String[] args)
    {
        System.out.println("main method stated");
        System.out.println("p value is"+ Demo98.p);
        System.out.println("q value is"+ Demo98.q);
        System.out.println("re-initilize static variable p and q");
        Demo98.p = 30;
        Demo98.q = 40;
        System.out.println("p value is"+ Demo98.p);
        System.out.println("q value is"+ Demo98.q);
        System.out.println("main method ended");
    }
}