class program3
{
    public static void main(String[] args){
    int n  = 10;
    int counter = 0;
    for(int i=1;i<=n;i++)
    {
        if(counter==0)
        System.out.print(i);
        else{
            counter++;
        System.out.print(counter);
        }
        for(int j=1;j<i;j++)
        {
            if(counter ==0)
            counter = i+1;
            else
            counter++;
            System.out.print(" "+counter);
        }
        System.out.print("\n");
    }

    
    }
}