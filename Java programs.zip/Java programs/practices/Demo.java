class Demo

    public class Test{
       
        
    public static void main(String[] args) {
        int a =10;


        
        System.out.println(a);
        a=true;
        System.out.println(a);


   
}
}
    