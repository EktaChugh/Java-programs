class Demo97
{
    int x = 100;
    int y = 200;
    void test()
    {
    System.out.println("running non static test()...");
    }
}   class MainClass3
{
    public static void main(String[] args){
     System.out.println("main method started");  
     System.out.println("x value is"+new Demo97().x);
     System.out.println("y value is"+new Demo97().y);
     new Demo97().test();
     System.out.println("main method ended"); 
    }
}
