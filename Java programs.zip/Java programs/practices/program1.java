class program1
{
    public static void main(String[] agrs){
        System.out.println("program Started");
        int n=9;
        if(n>9)
        {
            System.out.println("Number is above 7");
        }
        else{
            //System.out.println("Number is below 9");
            System.out.println("Number is equal 9");
        }
        System.out.println("program ended");
    }
}