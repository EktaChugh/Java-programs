import java.util.Scanner;
public class Demo100
{
    public static void main(String[] agrs){
        System.out.println("main method started");
        Scanner Data = new Scanner(System.in);
        System.out.println("Enter User_Name");
        String User_Name = Data.next();
        System.out.println("Enter User_age");
        int User_age = Data.nextInt();
        System.out.println("Enter User_contract");
        long User_contract = Data.nextLong();
        System.out.println("Enter User_marks");
        double User_marks = Data.nextDouble();
        System.out.println(User_Name+" " +User_age+" "+User_contract+" "+User_marks);


    }
}