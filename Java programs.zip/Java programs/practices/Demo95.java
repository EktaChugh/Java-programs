class Demo95
{
    int x = 100;
    double y = 2.00;
}
class MainClass5
{
    public static void main(String[] args){
        System.out.println("main method started");
        Demo95 d1 = new Demo95();
        Demo95 d2 = new Demo95();
        
        System.out.println("using d1");

        System.out.println("x value is"+ d1.x+"y value is "+d1.y);
        System.out.println("using d2");

        System.out.println("x value is"+ d2.x+"y value is "+d2.y);
        System.out.println("modify x and y value");
        d1.x=200;
        d2.y=8.5;
        System.out.println("using d1 printing value x and y");
        System.out.println("x value is"+ d1.x+"y value is "+d1.y);
        System.out.println("using d2 printing value x and y");
        System.out.println("x value is"+ d2.x+"y value is "+d2.y);
    }
}